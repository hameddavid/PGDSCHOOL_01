<?php

use App\Http\Controllers\Admin\AuthController;
use App\Http\Controllers\Users\AdmissionOfficer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::any('/getApplicants', [AdmissionOfficer::class , 'getApplicants']);
Route::any('/getApplications', [AdmissionOfficer::class , 'getApplications']);
Route::any('/getForms', [AdmissionOfficer::class , 'getForms']);
Route::any('/downloadFile', [AuthController::class , 'downloadFile']);
Route::any('/adminsionApproved', [AdmissionOfficer::class , 'adminsionApproved']);

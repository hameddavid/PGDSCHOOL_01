<?php

namespace App\Http\Controllers\Users;

use App\Http\Controllers\Controller;
use App\Models\Admission\application_assessment;
use App\Models\Admission\application_credentials;
use App\Models\Applicant;
use App\Models\Application;
use App\Models\Programme;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class AdmissionOfficer extends Controller
{
    public function getApplicants(Request $request)
    {
        try {
            $applicants = Applicant::latest()->get();
        foreach ($applicants as $key => $value) {
            $applications = Application::where('applicant_id',$value->id)->get();
            $applicants[$key]['applications'] = $applications;
        }
        return response()->json(['msg'=>'success', 'applicants'=>$applicants]) ;
        } catch (\Throwable $th) {
            //throw $th;
        return response()->json(['error'=>'Unable to fetch applicants', 'th'=>$th],401) ;
        }
    }
    public function getApplicationsDetails(Request $request)
    {

    }
    public function getApplications(Request $request)
    {
        try {
            $applications = Application::latest()->get();
            foreach ($applications as $key => $value) {
                $applicant = Applicant::find($value->applicant_id)->setHidden(['password','token']);
                $applications[$key]['applicant'] = $applicant;
            }
        return response()->json(['msg'=>'success', 'applications'=>$applications]) ;
        } catch (\Throwable $th) {
            //throw $th;
        return response()->json(['error'=>'Unable to fetch applications', 'th'=>$th],401) ;

        }
    }
    public function getForms(Request $request)
    {
        try {
            $application = Application::find($request->applicationId);
            $personalData = DB::table('application_personaldata')->where('applicant_id',$application->applicant_id)->first();
            $credentials = application_credentials::where('application_id',$request->applicationId)->first();
            $assessment = application_assessment::where('application_id',$request->applicationId)->first();
            $programme = Programme::find($assessment->programme_id);
            $assessment['programme'] = $programme->programme;
            $reference = DB::table('application_refree')->where('application_id',$request->applicationId)->get();
            $institutionHistory = DB::table('application_institution')->where('application_id', $request->applicationId)->get();
            $employmentHistory  = DB::table('application_employmenthistory')->where('application_id', $request->applicationId )->get();
            return response()->json(['personalData'=>$personalData, 'credentials'=>$credentials,
                                    'assessment'=>$assessment , 'reference'=>$reference, 'institutionHistory'=>$institutionHistory,
                                    'employmentHistory'=>$employmentHistory]);
        } catch (\Throwable $th) {
            //throw $th;
            return response()->json(['error'=>'Unable to get forms' , 'th'=>$th], 401);
        }


    }

    public function adminsionApproved(Request $request)
    {
        //Check for role and permission

        //validate the request fields
        $validator = Validator::make($request->all(), [
            'applicationId' => 'required',
            'programmeId' => 'required',
            'admsStatus' => 'required'
        ]);
        if($validator->fails()){ return response()->json(['error'=>'all fields are required!'],401) ;}
        //Use try/catch for application_assessment
        try {
            $getProgramme = Programme::find($request->programmeId);
            $applicant = DB::table('applicants')->join('applications', 'applicants.id', 'applications.applicant_id')->first();
            if(isset($getProgramme) && $applicant !=''){
            if($request->admsStatus == 'Y'){
                    $update = DB::table('application_assessment')->where('application_id', $request->applicationId)->update(['approved_programme_id' => $request->programmeId]);
                    //send admission success email to student here
                    return response()->json(['programme'=>$getProgramme]);
                }
            else{
                     //send admission decline email to student here
            }

            }
            else{
                return response()->json(['error'=>'Like there is no programmefor this ID'], 401);

            }

        }
         catch (\Throwable $th) {
            return response()->json(['error'=>'Error updating programme' , 'th'=>$th], 401);
        }


    }


}
